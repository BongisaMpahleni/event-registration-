/**
 * Event.java
 * This class creates and stores the attendee details in a sequential textfile
 * @author Kruben Naidoo
 * Date: Sunday, 28 June 2020
 */

package eventregistration;
import java.io.*;
import javax.swing.JOptionPane;

public class Event {
    private String studentNumber;
    private String firstName;
    private String lastName;
    private String programme;
    private String hasData;
    private String hasDevice;
    
    public Event(String studentNumber, String firstName, String lastName, String programme, String hasData, String hasDevice) {
        this.studentNumber = studentNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.programme = programme;
        this.hasData = hasData;
        this.hasDevice = hasDevice;
    }
    
    public void save() {
        PrintWriter out = null;
        String message = "The information is saved";
        try {
            // Create a print writer on this file in append mode
            out = new PrintWriter(new FileWriter("event.txt", true));
            out.println(studentNumber);
            out.println(firstName);
            out.println(lastName);
            out.println(programme);
            out.println(hasData);
            out.println(hasDevice);
        }
        catch  (IOException e) {
            // Catch any IO exceptions
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        finally {
            // Close the file print writer
            out.close();
        }
        JOptionPane.showMessageDialog(null, message, "Status", JOptionPane.INFORMATION_MESSAGE);
    }  
}
			